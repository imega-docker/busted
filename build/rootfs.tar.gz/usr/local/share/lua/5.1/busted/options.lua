return {
  standalone = true,
  defaultOutput = 'utfTerminal',
}
